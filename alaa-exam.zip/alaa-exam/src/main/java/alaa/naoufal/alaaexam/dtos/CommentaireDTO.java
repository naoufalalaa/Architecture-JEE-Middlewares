package alaa.naoufal.alaaexam.dtos;

public class CommentaireDTO {
}
