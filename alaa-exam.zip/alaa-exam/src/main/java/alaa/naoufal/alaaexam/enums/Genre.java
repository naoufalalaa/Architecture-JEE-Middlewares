package alaa.naoufal.alaaexam.enums;

public enum Genre {
    MASCULIN, FEMININ
}
