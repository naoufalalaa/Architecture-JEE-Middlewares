package alaa.naoufal.alaaexam.repositories;

import alaa.naoufal.alaaexam.entities.Salle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalleRepository extends JpaRepository<Salle, Long> {

}
