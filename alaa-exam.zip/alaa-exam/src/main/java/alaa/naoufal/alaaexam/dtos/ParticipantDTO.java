package alaa.naoufal.alaaexam.dtos;

import lombok.Data;

@Data
public class ParticipantDTO {
    private String type;
}
