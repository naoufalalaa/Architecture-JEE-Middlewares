package alaa.naoufal.alaaexam.repositories;

import alaa.naoufal.alaaexam.entities.Invite;
import alaa.naoufal.alaaexam.entities.Participant;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ParticipantRepository extends JpaRepository<Participant, Long> {

}
