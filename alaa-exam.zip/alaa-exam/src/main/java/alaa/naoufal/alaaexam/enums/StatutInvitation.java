package alaa.naoufal.alaaexam.enums;

public enum StatutInvitation {
    ENCOURS,
    VALIDEE,
    ANNULEE
}
